package me.alpha432.oyvey.features.modules.hud;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.event.impl.Render2DEvent;
import me.alpha432.oyvey.features.modules.client.HudModule;

public class SpeedHud extends HudModule {

    private final int blue = 0xFF3399FF;
    private final int white = 0xFFFFFFFF;

    public SpeedHud() {
        super("Speed", "Displays your movement speed", 5, 35);
    }

    @Subscribe
public void onRender2D(Render2DEvent e) {
    if (mc.field_1724 == null) return;

    double dx = mc.field_1724.method_23317() - mc.field_1724.field_6014;
    double dz = mc.field_1724.method_23321() - mc.field_1724.field_5969;

    double speed = Math.sqrt(dx * dx + dz * dz) * 20.0;

    String name = "Speed: ";
    String value = String.format("%.2f", speed);

    int x = (int) getX();
    int y = (int) getY();

    e.getContext().method_25303(
            mc.field_1772,
            name,
            x,
            y,
            blue
    );

    e.getContext().method_25303(
            mc.field_1772,
            value,
            x + mc.field_1772.method_1727(name),
            y,
            white
    );
}
}
