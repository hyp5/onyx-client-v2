package me.alpha432.oyvey.features.modules.player;

import me.alpha432.oyvey.features.modules.Module;
import net.minecraft.class_1802;

public class FastPlace extends Module {
    public FastPlace() {
        super("FastPlace", "Makes you throw exp faster", Category.PLAYER);
    }

    @Override
    public void onUpdate() {
        if (nullCheck()) return;

        if (mc.field_1724.method_24518(class_1802.field_8287)) {
            mc.field_1752 = 0;
        }
    }
}
