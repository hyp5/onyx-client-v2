package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.settings.Setting;
import net.minecraft.class_5134;

public class Step extends Module {
    private final Setting<Float> height = num("Height", 2f, 1f, 3f);

    public Step() {
        super("Step", "step..", Category.MOVEMENT);
    }

    private float prev;

    @Override
    public void onEnable() {
        if (nullCheck()) {
            prev = 0.6f;
            return;
        }
        prev = mc.field_1724.method_49476();
    }

    @Override
    public void onDisable() {
        if (nullCheck()) return;
        mc.field_1724.method_5996(class_5134.field_47761).method_6192(prev);
    }

    @Override
    public void onUpdate() {
        if (nullCheck()) return;
        mc.field_1724.method_5996(class_5134.field_47761).method_6192(height.getValue());
    }
}
