package me.alpha432.oyvey.features.modules.combat;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.event.impl.PacketEvent;
import me.alpha432.oyvey.features.modules.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_2824;
import net.minecraft.class_2828;

public class Criticals extends Module {
    public Criticals() {
        super("Criticals", "Makes you do critical hits", Category.COMBAT);
    }

    @Subscribe
    private void onPacketSend(PacketEvent.Send event) {
        if (event.getPacket() instanceof class_2824 packet && packet.field_12871.method_34211() == class_2824.class_5907.field_29172) {
            class_1297 entity = mc.field_1687.method_8469(packet.field_12870);
            if (entity == null
                    || entity instanceof class_1511
                    || !mc.field_1724.method_24828()
                    || !(entity instanceof class_1309)) return;

            boolean bl = mc.field_1724.field_5976;
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 0.1f, mc.field_1724.method_23321(), false, bl));
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), false, bl));
            mc.field_1724.method_7277(entity);
        }
    }

    @Override
    public String getDisplayInfo() {
        return "Packet";
    }
}
