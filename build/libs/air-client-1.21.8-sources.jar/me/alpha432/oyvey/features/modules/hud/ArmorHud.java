package me.alpha432.oyvey.features.modules.hud;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.event.impl.Render2DEvent;
import me.alpha432.oyvey.features.modules.client.HudModule;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class ArmorHud extends HudModule {

    public ArmorHud() {
        super("ArmorHud", "Displays your armor", 200, 20);
    }

    @Override
    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (nullCheck()) return;

        class_332 context = e.getContext();

        int baseX = (int) getX();
        int baseY = (int) getY();

        class_1304[] slots = {
                class_1304.field_6169,
                class_1304.field_6174,
                class_1304.field_6172,
                class_1304.field_6166
        };

        int spacing = 18;
        int index = 0;

        for (class_1304 slot : slots) {

            class_1799 stack = mc.field_1724.method_6118(slot);
            if (stack.method_7960()) continue;

            int x = baseX + index * spacing;
            int y = baseY;

            // Рисуем предмет
            context.method_51427(stack, x, y);

            // === ПРОЧНОСТЬ ===
            if (stack.method_7963()) {

                int max = stack.method_7936();
                int current = max - stack.method_7919();
                int percent = Math.round((current * 100f) / max);

                String text = String.valueOf(percent);

                int textWidth = mc.field_1772.method_1727(text);

                // Центрируем по предмету
                int textX = x + 8 - textWidth / 2;

                // Ставим снизу как в Meteor
                int textY = y + 16 - mc.field_1772.field_2000;

                context.method_27535(
                        mc.field_1772,
                        class_2561.method_43470(text),
                        textX,
                        textY,
                        0x00FF00 // зелёный
                );
            }

            index++;
        }

        setWidth(index * spacing);
        setHeight(16);
    }
}
