package me.alpha432.oyvey.features.modules.hud;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.event.impl.Render2DEvent;
import me.alpha432.oyvey.features.modules.client.HudModule;

public class FPSHud extends HudModule {

    private final int blue = 0xFF3399FF;
    private final int white = 0xFFFFFFFF;

    public FPSHud() {
        super("FPS", "Displays your FPS", 5, 5);
    }

    @Subscribe
public void onRender2D(Render2DEvent e) {
    if (mc.field_1724 == null) return;

    int fps = mc.method_47599();

    String name = "FPS: ";
    String value = String.valueOf(fps);

    int x = (int) getX();
    int y = (int) getY();

    // Синий заголовок
    e.getContext().method_25303(
            mc.field_1772,
            name,
            x,
            y,
            blue
    );

    // Белое значение
    e.getContext().method_25303(
            mc.field_1772,
            value,
            x + mc.field_1772.method_1727(name),
            y,
            white
    );
}
}
