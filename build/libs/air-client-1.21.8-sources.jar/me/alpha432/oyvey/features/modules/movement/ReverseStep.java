package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.features.modules.Module;

public class ReverseStep extends Module {
    public ReverseStep() {
        super("ReverseStep", "step but reversed..", Category.MOVEMENT);
    }

    @Override
    public void onUpdate() {
        if (nullCheck()) return;
        if (mc.field_1724.method_5771() || mc.field_1724.method_5799() || !mc.field_1724.method_24828()) return;
        mc.field_1724.method_5762(0, -1, 0);
    }
}
