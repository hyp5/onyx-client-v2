package me.alpha432.oyvey.features.modules.render;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.event.impl.Render3DEvent;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.settings.Setting;
import me.alpha432.oyvey.util.render.RenderUtil;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_3965;
import java.awt.*;

public class BlockHighlight extends Module {
    public Setting<Color> color = color("Color", 255, 0, 0, 255);
    public Setting<Float> lineWidth = num("LineWidth", 1.0f, 0.1f, 5.0f);

    public BlockHighlight() {
        super("BlockHighlight", "Draws box at the block that you are looking at", Category.RENDER);
    }

    @Subscribe
    public void onRender3D(Render3DEvent event) {
        if (mc.field_1765 instanceof class_3965 result) {
            class_265 shape = mc.field_1687.method_8320(result.method_17777()).method_26218(mc.field_1687, result.method_17777());
            if (shape.method_1110()) return;
            class_238 box = shape.method_1107();
            box = box.method_996(result.method_17777());
            RenderUtil.drawBox(event.getMatrix(), box, color.getValue(), lineWidth.getValue());
        }
    }
}
