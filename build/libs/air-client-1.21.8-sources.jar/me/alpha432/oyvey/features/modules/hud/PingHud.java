package me.alpha432.oyvey.features.modules.hud;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.event.impl.Render2DEvent;
import me.alpha432.oyvey.features.modules.client.HudModule;
import net.minecraft.class_640;

public class PingHud extends HudModule {

    private final int blue = 0xFF3399FF;
    private final int white = 0xFFFFFFFF;

    public PingHud() {
        super("Ping", "Displays your ping", 5, 20);
    }

    @Subscribe
public void onRender2D(Render2DEvent e) {
    if (mc.field_1724 == null || mc.method_1562() == null) return;

    class_640 entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
    int ping = entry != null ? entry.method_2959() : 0;

    String name = "Ping: ";
    String value = ping + " ms";

    int x = (int) getX();
    int y = (int) getY();

    e.getContext().method_25303(
            mc.field_1772,
            name,
            x,
            y,
            blue
    );

    e.getContext().method_25303(
            mc.field_1772,
            value,
            x + mc.field_1772.method_1727(name),
            y,
            white
    );
}
}
