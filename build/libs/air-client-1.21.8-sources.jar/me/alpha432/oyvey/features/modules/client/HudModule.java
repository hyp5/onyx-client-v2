package me.alpha432.oyvey.features.modules.client;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.event.impl.MouseEvent;
import me.alpha432.oyvey.event.impl.Render2DEvent;
import me.alpha432.oyvey.features.gui.HudEditorScreen;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.settings.Setting;
import me.alpha432.oyvey.util.render.RenderUtil;
import net.minecraft.class_408;
import org.joml.Vector2f;

public abstract class HudModule extends Module {
    public final Setting<Vector2f> pos = vec2f("Position", 0.5f, 0.5f);

    private float dragX, dragY, width, height;
    private boolean dragging, button;

    public HudModule(String name, String description, float width, float height) {
        super(name, description, Category.HUD);
        this.width = width;
        this.height = height;
    }

    public float getX() {
        return mc.method_22683().method_4486() * pos.getValue().x();
    }

    public float getY() {
        float heightWithChat = mc.method_22683().method_4502() - 14;
        float baseY = mc.method_22683().method_4502() * pos.getValue().y();
        float combined = baseY + getHeight();

        if (mc.field_1755 instanceof class_408) {
            baseY = Math.min(combined, heightWithChat) - getHeight();
        }
        return baseY;
    }

    @Subscribe
    public void onRender2DHud(Render2DEvent e) {
        if (!(mc.field_1755 instanceof HudEditorScreen) || nullCheck() || OyVey.hudEditorScreen == null) return;

        float x = getX();
        float y = getY();

        if (button) {
            if (!dragging && isHovering() && OyVey.hudEditorScreen.currentDragging == null) {
                dragX = getMouseX() - x;
                dragY = getMouseY() - y;
                dragging = true;
                OyVey.hudEditorScreen.currentDragging = this;
            }

            if (dragging) {
                float finalX = Math.min(Math.max(getMouseX() - dragX, 0),
                        mc.method_22683().method_4486() - width);
                float finalY = Math.min(Math.max(getMouseY() - dragY, 0),
                        mc.method_22683().method_4502() - height);

                pos.getValue().x = finalX / mc.method_22683().method_4486();
                pos.getValue().y = finalY / mc.method_22683().method_4502();
            }
        } else {
            dragging = false;
        }

        boolean shouldDrawDescription = isHovering() && !OyVey.hudEditorScreen.anyHover;
        if (OyVey.hudEditorScreen.currentDragging != null) {
            shouldDrawDescription = OyVey.hudEditorScreen.currentDragging == this;
        }

        if (shouldDrawDescription) {
            int textWidth = mc.field_1772.method_1727(getName());
            int textHeight = mc.field_1772.field_2000;
            float textX = x + width + 5;
            if (textX + textWidth > mc.method_22683().method_4486()) {
                textX = x - 5 - textWidth;
            }
            e.getContext().method_25303(mc.field_1772, getName(),
                    (int) textX, (int) (y + height / 2f - textHeight / 2f), -1);
            OyVey.hudEditorScreen.anyHover = true;
        }

        RenderUtil.rect(e.getContext(),
                x - 1, y - 1, x + width + 1, y + height + 1,
                OyVey.colorManager.getColor().getRGB(), 1.0f);
    }

    @Subscribe
    public void onMouse(MouseEvent e) {
        if (!(mc.field_1755 instanceof HudEditorScreen) || nullCheck()) return;
        if (OyVey.hudEditorScreen == null) return;

        if (e.getAction() == 0) {
            button = false;
            dragging = false;
            OyVey.hudEditorScreen.currentDragging = null;
        }

        if (e.getAction() == 1 && isHovering()) {
            button = true;
        }
    }

    public int getMouseX() {
        return (int) (mc.field_1729.method_1603() / mc.method_22683().method_4495());
    }

    public int getMouseY() {
        return (int) (mc.field_1729.method_1604() / mc.method_22683().method_4495());
    }

    public void setBounds(float x, float y, float width, float height) {
        this.width = width;
        this.height = height;
        pos.getValue().x = x / mc.method_22683().method_4486();
        pos.getValue().y = y / mc.method_22683().method_4502();
    }

    public boolean isHovering() {
        float x = getX();
        float y = getY();
        int mouseX = getMouseX();
        int mouseY = getMouseY();

        return mouseX >= x - 1 && mouseX <= x + width + 1 &&
                mouseY >= y - 1 && mouseY <= y + height + 1;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public void setHeight(float height) {
        this.height = height;
    }
}
