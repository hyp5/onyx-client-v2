package me.alpha432.oyvey.features.modules.player;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.event.impl.PacketEvent;
import me.alpha432.oyvey.features.modules.Module;
import net.minecraft.class_2664;
import net.minecraft.class_2743;

public class Velocity extends Module {
    public Velocity() {
        super("Velocity", "Removes velocity from explosions and entities", Category.PLAYER);
    }

    @Subscribe
    private void onPacketReceive(PacketEvent.Receive event) {
        if (event.getPacket() instanceof class_2743 || event.getPacket() instanceof class_2664)
            event.cancel();
    }
}
