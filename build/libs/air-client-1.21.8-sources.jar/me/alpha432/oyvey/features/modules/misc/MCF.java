package me.alpha432.oyvey.features.modules.misc;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.commands.Command;
import me.alpha432.oyvey.features.modules.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.lwjgl.glfw.GLFW;

public class MCF extends Module {
    private boolean pressed;

    public MCF() {
        super("MCF", "Middle click friend", Category.MISC);
    }

    @Override
    public void onTick() {
        if (GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), 2) == 1) {
            if (!pressed) click();
            pressed = true;
        } else {
            pressed = false;
        }
    }

    private void click() {
        class_1297 targetedEntity = mc.field_1692;
        if (!(targetedEntity instanceof class_1657)) return;
        String name = ((class_1657) targetedEntity).method_7334().getName();

        if (OyVey.friendManager.isFriend(name)) {
            OyVey.friendManager.removeFriend(name);

            Command.sendMessage("{red} %s has been unfriended.", name);
        } else {
            OyVey.friendManager.addFriend(name);
            Command.sendMessage("{aqua} %s has been friended.", name);
        }
    }
}
