package me.alpha432.oyvey.features.modules.player;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.modules.Module;
import net.minecraft.class_2828;

public class NoFall extends Module {
    public NoFall() {
        super("NoFall", "Removes fall damage", Category.PLAYER);
    }

    @Override
    public void onUpdate() {
        if (!mc.field_1724.method_24828() && OyVey.positionManager.getFallDistance() > 3) {
            boolean bl = mc.field_1724.field_5976;
            class_2828.class_2830 pakcet = new class_2828.class_2830(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 0.000000001, mc.field_1724.method_23321(),
                    mc.field_1724.method_36454(), mc.field_1724.method_36455(), false, bl);
            mc.field_1724.field_3944.method_52787(pakcet);
        }
    }
}
