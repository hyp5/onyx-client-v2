package me.alpha432.oyvey.features.modules.hud;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.event.impl.Render2DEvent;
import me.alpha432.oyvey.features.modules.client.HudModule;
import me.alpha432.oyvey.features.settings.Setting;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import java.awt.Color;

public class Coordinates extends HudModule {

    public Setting<Boolean> nether = register(new Setting<>("NetherCoords", true));
    public Setting<Boolean> shadow = register(new Setting<>("Shadow", true));

    public Coordinates() {
        super("Coordinates", "Display coordinates and compass", 100, 40);
    }

    private enum Direction {
        N("N"), E("E"), S("S"), W("W");

        private final String label;
        Direction(String label) { this.label = label; }
        public String getLabel() { return label; }
    }

    @Override
    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (nullCheck()) return;

        int x = mc.field_1724.method_31477();
        int y = mc.field_1724.method_31478();
        int z = mc.field_1724.method_31479();

        class_2960 dimension = mc.field_1724.method_37908().method_27983().method_29177();
        boolean inNether = dimension.method_12832().equals("the_nether");

        int baseX = (int) getX();
        int baseY = (int) getY();

        // Основной текст с координатами
        String main = "XYZ: " + x + ", " + y + ", " + z;
        e.getContext().method_27535(
                mc.field_1772,
                class_2561.method_43470(main),
                baseX,
                baseY,
                Color.WHITE.getRGB()
        );

        int height = mc.field_1772.field_2000;

        // Дополнительные координаты Overworld/Nether
        if (nether.getValue()) {
            String second;
            if (inNether) {
                second = "Overworld: " + (x * 8) + ", " + (z * 8);
            } else {
                second = "Nether: " + (x / 8) + ", " + (z / 8);
            }

            e.getContext().method_27535(
                    mc.field_1772,
                    class_2561.method_43470(second),
                    baseX,
                    baseY + height + 2,
                    0xAAAAFF
            );

            setHeight(height * 2 + 2);
            setWidth(Math.max(
                    mc.field_1772.method_1727(main),
                    mc.field_1772.method_1727(second)
            ));
        } else {
            setHeight(height);
            setWidth(mc.field_1772.method_1727(main));
        }

        // Компас
        double yaw = Math.toRadians(class_3532.method_15393(mc.field_1724.method_36454()));
        double compassScale = 40; // радиус "компаса"
        int centerX = baseX + (int)(getWidth() / 2.0f);
        int centerY = baseY - 20; // над координатами

        for (Direction dir : Direction.values()) {
            double angle = yaw + dir.ordinal() * Math.PI / 2;
            int dx = (int) (Math.sin(angle) * compassScale);
            int dy = (int) (-Math.cos(angle) * compassScale); // - чтобы Y шло вниз

            int color = dir == Direction.N ? 0x2255FF : 0xAAAAAA; // синий для N, серый для остальных
            e.getContext().method_27535(
                    mc.field_1772,
                    class_2561.method_43470(dir.getLabel()),
                    centerX + dx - mc.field_1772.method_1727(dir.getLabel()) / 2,
                    centerY + dy - mc.field_1772.field_2000 / 2,
                    color
            );
        }
    }
}
