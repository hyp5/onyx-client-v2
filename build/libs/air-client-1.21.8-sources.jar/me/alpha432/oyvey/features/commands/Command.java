package me.alpha432.oyvey.features.commands;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.Feature;
import me.alpha432.oyvey.util.TextUtil;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;


public abstract class Command
        extends Feature {
    protected String name;
    protected String[] commands;

    public Command(String name) {
        super(name);
        this.name = name;
        this.commands = new String[]{""};
    }

    public Command(String name, String[] commands) {
        super(name);
        this.name = name;
        this.commands = commands;
    }

    public static void sendMessage(String message, Object... obj) {
        sendMessage(TextUtil.text(message, obj));
    }

    public static void sendMessage(class_2561 message) {
        class_5250 text = class_2561.method_43473();
        text.method_27693(OyVey.commandManager.getClientMessage() + " " + class_124.field_1080);
        text.method_10852(message);
        Command.sendSilentMessage(text);
    }

    public static void sendSilentMessage(class_2561 message) {
        if (Command.nullCheck()) {
            return;
        }
        // TODO add silent support ig
        mc.field_1705.method_1743().method_1812(message);
    }

    public static String getCommandPrefix() {
        return OyVey.commandManager.getPrefix();
    }

    public abstract void execute(String[] var1);

    @Override
    public String getName() {
        return this.name;
    }

    public String[] getCommands() {
        return this.commands;
    }
}