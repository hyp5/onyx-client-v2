package me.alpha432.oyvey.features.gui;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.Feature;
import me.alpha432.oyvey.features.gui.items.Item;
import me.alpha432.oyvey.features.gui.items.buttons.ModuleButton;
import me.alpha432.oyvey.features.modules.Module;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;

public class OyVeyGui extends class_437 {
    private static OyVeyGui INSTANCE;
    private static Color colorClipboard = null;

    static {
        INSTANCE = new OyVeyGui();
    }

    private final ArrayList<Component> components = new ArrayList<>();

    public OyVeyGui() {
        super(class_2561.method_43470("OyVey"));
        setInstance();
        load();
    }

    public static OyVeyGui getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new OyVeyGui();
        }
        return INSTANCE;
    }

    public static OyVeyGui getClickGui() {
        return OyVeyGui.getInstance();
    }

    private void setInstance() {
        INSTANCE = this;
    }

    private void load() {
    this.components.clear();

    int screenWidth = net.minecraft.class_310.method_1551()
            .method_22683().method_4486();

    int startY = 4;
    int panelWidth = 88;      // ширина панели
    int panelHeader = 14;     // высота заголовка
    int spacing = 6;          // расстояние между панелями

    // Список категорий без HUD
    ArrayList<Module.Category> categories = new ArrayList<>();
    for (Module.Category category : OyVey.moduleManager.getCategories()) {
        if (category != Module.Category.HUD) {
            categories.add(category);
        }
    }

    // Сколько колонок помещается
    int columns = Math.max(1, screenWidth / (panelWidth + spacing));

    // Центровка
    int totalWidth = columns * (panelWidth + spacing);
    int startX = (screenWidth - totalWidth) / 2;

    int x = startX;
    int y = startY;
    int column = 0;

    for (Module.Category category : categories) {

        Component panel = new Component(category.getName(), x, y, true);

        OyVey.moduleManager.stream()
                .filter(m -> m.getCategory() == category && !m.hidden)
                .map(ModuleButton::new)
                .forEach(panel::addButton);

        this.components.add(panel);

        column++;
        if (column >= columns) {
            column = 0;
            x = startX;
            y += panelHeader + 120; // расстояние между строками
        } else {
            x += panelWidth + spacing;
        }
    }

    this.components.forEach(component ->
            component.getItems().sort(Comparator.comparing(Feature::getName))
    );
}
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        Item.context = context;
        context.method_25294(0, 0, context.method_51421(), context.method_51443(), new Color(0, 0, 0, 120).hashCode());
        this.components.forEach(components -> components.drawScreen(context, mouseX, mouseY, delta));
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int clickedButton) {
        this.components.forEach(components -> components.mouseClicked((int) mouseX, (int) mouseY, clickedButton));
        return super.method_25402(mouseX, mouseY, clickedButton);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int releaseButton) {
        this.components.forEach(components -> components.mouseReleased((int) mouseX, (int) mouseY, releaseButton));
        return super.method_25406(mouseX, mouseY, releaseButton);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount < 0) {
            this.components.forEach(component -> component.setY(component.getY() - 10));
        } else if (verticalAmount > 0) {
            this.components.forEach(component -> component.setY(component.getY() + 10));
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        this.components.forEach(component -> component.onKeyPressed(keyCode));
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        this.components.forEach(component -> component.onKeyTyped(chr, modifiers));
        return super.method_25400(chr, modifiers);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }//ignore 1.21.8 blur thing

    public final ArrayList<Component> getComponents() {
        return this.components;
    }

    public int getTextOffset() {
        return -6;
    }

    public static Color getColorClipboard() {
        return colorClipboard;
    }

    public static void setColorClipboard(Color color) {
        colorClipboard = color;
    }
}
