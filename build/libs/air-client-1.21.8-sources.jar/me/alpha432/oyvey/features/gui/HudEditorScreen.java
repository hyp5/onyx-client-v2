package me.alpha432.oyvey.features.gui;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.Feature;
import me.alpha432.oyvey.features.gui.items.buttons.ModuleButton;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.modules.client.HudModule;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.Comparator;

public class HudEditorScreen extends class_437 {
    private final ArrayList<Component> components = new ArrayList<>();
    public HudModule currentDragging;
    public boolean anyHover;

    public HudEditorScreen() {
        super(class_2561.method_43470("oyvey-hudeditor"));
        load();
    }

    private void load() {
        Component hud = new Component("Hud", 50, 50, true);
        OyVey.moduleManager.stream()
                .filter(m -> m.getCategory() == Module.Category.HUD && !m.hidden)
                .map(ModuleButton::new)
                .forEach(hud::addButton);
        this.components.add(hud);
        this.components.forEach(component -> component.getItems().sort(Comparator.comparing(Feature::getName)));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        anyHover = false;
        this.components.forEach(component -> component.drawScreen(context, mouseX, mouseY, delta));
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int clickedButton) {
        this.components.forEach(component -> component.mouseClicked((int) mouseX, (int) mouseY, clickedButton));
        return super.method_25402(mouseX, mouseY, clickedButton);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int releaseButton) {
        this.components.forEach(component -> component.mouseReleased((int) mouseX, (int) mouseY, releaseButton));
        return super.method_25406(mouseX, mouseY, releaseButton);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount < 0) {
            this.components.forEach(component -> component.setY(component.getY() - 10));
        } else if (verticalAmount > 0) {
            this.components.forEach(component -> component.setY(component.getY() + 10));
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        this.components.forEach(component -> component.onKeyPressed(keyCode));
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        this.components.forEach(component -> component.onKeyTyped(chr, modifiers));
        return super.method_25400(chr, modifiers);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override // ignore 1.21.8 menu blur thing
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
    }


    public ArrayList<Component> getComponents() {
        return components;
    }
}

