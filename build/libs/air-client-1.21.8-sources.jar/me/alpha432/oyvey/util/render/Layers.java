package me.alpha432.oyvey.util.render;

import java.util.OptionalDouble;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_4668;

import static me.alpha432.oyvey.util.render.Pipelines.GLOBAL_LINES_PIPELINE;
import static me.alpha432.oyvey.util.render.Pipelines.GLOBAL_QUADS_PIPELINE;

public class Layers {
    private static final class_1921 GLOBAL_QUADS;
    private static final Function<Double, class_1921> GLOBAL_LINES;

    public static class_1921 getGlobalLines(double width) {
        return GLOBAL_LINES.apply(width);
    }

    public static class_1921 getGlobalQuads() {
        return GLOBAL_QUADS;
    }

    private static class_1921.class_4688.class_4689 builder() {
        return class_1921.class_4688.method_23598();
    }

    private static class_1921.class_4688 empty() {
        return builder().method_23617(false);
    }

    static {
        GLOBAL_QUADS = class_1921.method_24048("global_fill", 156, GLOBAL_QUADS_PIPELINE, empty());

        GLOBAL_LINES = class_156.method_34866(l -> {
            class_4668.class_4677 width = new class_4668.class_4677(OptionalDouble.of(l));
            return class_1921.method_24048("global_lines", 156, GLOBAL_LINES_PIPELINE, builder().method_23609(width).method_23617(false));
        });
    }
}
