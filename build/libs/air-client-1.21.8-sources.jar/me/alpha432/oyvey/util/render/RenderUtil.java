package me.alpha432.oyvey.util.render;

import com.mojang.blaze3d.vertex.VertexFormat;
import me.alpha432.oyvey.util.traits.Util;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_9974;
import net.minecraft.client.render.*;
import java.awt.*;
import java.util.Objects;

public class RenderUtil implements Util {

    public static void rect(class_332 context, float x1, float y1, float x2, float y2, int color) {
        int ix1 = Math.round(x1);
        int iy1 = Math.round(y1);
        int ix2 = Math.round(x2);
        int iy2 = Math.round(y2);
        context.method_25294(ix1, iy1, ix2, iy2, color);
    }

    public static void rect(class_332 context, float x1, float y1, float x2, float y2, int color, float width) {
        int w = Math.max(1, Math.round(width));
        context.method_25294(Math.round(x1), Math.round(y1), Math.round(x2), Math.round(y1) + w, color);
        context.method_25294(Math.round(x2) - w, Math.round(y1), Math.round(x2), Math.round(y2), color);
        context.method_25294(Math.round(x1), Math.round(y2) - w, Math.round(x2), Math.round(y2), color);
        context.method_25294(Math.round(x1), Math.round(y1), Math.round(x1) + w, Math.round(y2), color);
    }

    public static void horizontalGradient(class_332 context, float x1, float y1, float x2, float y2, Color left, Color right) {
        int ix1 = Math.round(x1);
        int iy1 = Math.round(y1);
        int ix2 = Math.round(x2);
        int iy2 = Math.round(y2);
        int width = Math.max(1, ix2 - ix1);
        for (int i = 0; i < width; i++) {
            float t = width == 1 ? 1f : (float) i / (float) (width - 1);
            int r = (int) (left.getRed() + (right.getRed() - left.getRed()) * t);
            int g = (int) (left.getGreen() + (right.getGreen() - left.getGreen()) * t);
            int b = (int) (left.getBlue() + (right.getBlue() - left.getBlue()) * t);
            int a = (int) (left.getAlpha() + (right.getAlpha() - left.getAlpha()) * t);
            int argb = (a & 0xFF) << 24 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | (b & 0xFF);
            context.method_25294(ix1 + i, iy1, ix1 + i + 1, iy2, argb);
        }
    }

    public static void verticalGradient(class_332 context, float x1, float y1, float x2, float y2, Color top, Color bottom) {
        int ix1 = Math.round(x1);
        int iy1 = Math.round(y1);
        int ix2 = Math.round(x2);
        int iy2 = Math.round(y2);
        int height = Math.max(1, iy2 - iy1);
        for (int i = 0; i < height; i++) {
            float t = height == 1 ? 1f : (float) i / (float) (height - 1);
            int r = (int) (top.getRed() + (bottom.getRed() - top.getRed()) * t);
            int g = (int) (top.getGreen() + (bottom.getGreen() - top.getGreen()) * t);
            int b = (int) (top.getBlue() + (bottom.getBlue() - top.getBlue()) * t);
            int a = (int) (top.getAlpha() + (bottom.getAlpha() - top.getAlpha()) * t);
            int argb = (a & 0xFF) << 24 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | (b & 0xFF);
            context.method_25294(ix1, iy1 + i, ix2, iy1 + i + 1, argb);
        }
    }

    public static void rect(class_4587 stack, float x1, float y1, float x2, float y2, int color) {
        rectFilled(stack, x1, y1, x2, y2, color);
    }

    public static void rect(class_4587 stack, float x1, float y1, float x2, float y2, int color, float width) {
        drawHorizontalLine(stack, x1, x2, y1, color, width);
        drawVerticalLine(stack, x2, y1, y2, color, width);
        drawHorizontalLine(stack, x1, x2, y2, color, width);
        drawVerticalLine(stack, x1, y1, y2, color, width);
    }

    protected static void drawHorizontalLine(class_4587 matrices, float x1, float x2, float y, int color) {
        if (x2 < x1) {
            float i = x1;
            x1 = x2;
            x2 = i;
        }

        rectFilled(matrices, x1, y, x2 + 1, y + 1, color);
    }

    protected static void drawVerticalLine(class_4587 matrices, float x, float y1, float y2, int color) {
        if (y2 < y1) {
            float i = y1;
            y1 = y2;
            y2 = i;
        }

        rectFilled(matrices, x, y1 + 1, x + 1, y2, color);
    }

    protected static void drawHorizontalLine(class_4587 matrices, float x1, float x2, float y, int color, float width) {
        if (x2 < x1) {
            float i = x1;
            x1 = x2;
            x2 = i;
        }

        rectFilled(matrices, x1, y, x2 + width, y + width, color);
    }

    protected static void drawVerticalLine(class_4587 matrices, float x, float y1, float y2, int color, float width) {
        if (y2 < y1) {
            float i = y1;
            y1 = y2;
            y2 = i;
        }

        rectFilled(matrices, x, y1 + width, x + width, y2, color);
    }

    public static void rectFilled(class_4587 matrix, float x1, float y1, float x2, float y2, int color) {
        float i;
        if (x1 < x2) {
            i = x1;
            x1 = x2;
            x2 = i;
        }

        if (y1 < y2) {
            i = y1;
            y1 = y2;
            y2 = i;
        }

        float f = (float) (color >> 24 & 255) / 255.0F;
        float g = (float) (color >> 16 & 255) / 255.0F;
        float h = (float) (color >> 8 & 255) / 255.0F;
        float j = (float) (color & 255) / 255.0F;

        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y2, 0.0F).method_22915(g, h, j, f);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y2, 0.0F).method_22915(g, h, j, f);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y1, 0.0F).method_22915(g, h, j, f);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y1, 0.0F).method_22915(g, h, j, f);

        Layers.getGlobalQuads().method_60895(bufferBuilder.method_60800());
    }

    public static void horizontalGradient(class_4587 matrix, float x1, float y1, float x2, float y2, Color left, Color right) {
        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y1, 0.0F).method_22915(left.getRed() / 255.0F, left.getGreen() / 255.0F, left.getBlue() / 255.0F, left.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y2, 0.0F).method_22915(left.getRed() / 255.0F, left.getGreen() / 255.0F, left.getBlue() / 255.0F, left.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y2, 0.0F).method_22915(right.getRed() / 255.0F, right.getGreen() / 255.0F, right.getBlue() / 255.0F, right.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y1, 0.0F).method_22915(right.getRed() / 255.0F, right.getGreen() / 255.0F, right.getBlue() / 255.0F, right.getAlpha() / 255.0F);

        Layers.getGlobalQuads().method_60895(bufferBuilder.method_60800());
    }

    public static void verticalGradient(class_4587 matrix, float x1, float y1, float x2, float y2, Color top, Color bottom) {
        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y1, 0.0F).method_22915(top.getRed() / 255.0F, top.getGreen() / 255.0F, top.getBlue() / 255.0F, top.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y2, 0.0F).method_22915(bottom.getRed() / 255.0F, bottom.getGreen() / 255.0F, bottom.getBlue() / 255.0F, bottom.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y2, 0.0F).method_22915(bottom.getRed() / 255.0F, bottom.getGreen() / 255.0F, bottom.getBlue() / 255.0F, bottom.getAlpha() / 255.0F);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y1, 0.0F).method_22915(top.getRed() / 255.0F, top.getGreen() / 255.0F, top.getBlue() / 255.0F, top.getAlpha() / 255.0F);

        Layers.getGlobalQuads().method_60895(bufferBuilder.method_60800());
    }

    // 3d
    public static void drawBoxFilled(class_4587 stack, class_238 box, Color c) {
        float minX = (float) (box.field_1323 - mc.method_1561().field_4686.method_19326().method_10216());
        float minY = (float) (box.field_1322 - mc.method_1561().field_4686.method_19326().method_10214());
        float minZ = (float) (box.field_1321 - mc.method_1561().field_4686.method_19326().method_10215());
        float maxX = (float) (box.field_1320 - mc.method_1561().field_4686.method_19326().method_10216());
        float maxY = (float) (box.field_1325 - mc.method_1561().field_4686.method_19326().method_10214());
        float maxZ = (float) (box.field_1324 - mc.method_1561().field_4686.method_19326().method_10215());

        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(c.getRGB());

        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(c.getRGB());

        Layers.getGlobalQuads().method_60895(bufferBuilder.method_60800());
    }

    public static void drawBoxFilled(class_4587 stack, class_243 vec, Color c) {
        drawBoxFilled(stack, class_238.method_29968(vec), c);
    }

    public static void drawBoxFilled(class_4587 stack, class_2338 bp, Color c) {
        drawBoxFilled(stack, new class_238(bp), c);
    }

    public static void drawBox(class_4587 stack, class_238 box, Color c, double lineWidth) {
        float minX = (float) (box.field_1323 - mc.method_1561().field_4686.method_19326().method_10216());
        float minY = (float) (box.field_1322 - mc.method_1561().field_4686.method_19326().method_10214());
        float minZ = (float) (box.field_1321 - mc.method_1561().field_4686.method_19326().method_10215());
        float maxX = (float) (box.field_1320 - mc.method_1561().field_4686.method_19326().method_10216());
        float maxY = (float) (box.field_1325 - mc.method_1561().field_4686.method_19326().method_10214());
        float maxZ = (float) (box.field_1324 - mc.method_1561().field_4686.method_19326().method_10215());

        class_287 bufferBuilder = class_289.method_1348()
                .method_60827(VertexFormat.class_5596.field_27377, class_290.field_29337);

        class_9974.method_62292(stack, bufferBuilder, minX, minY, minZ, maxX, maxY, maxZ,
                c.getRed() / 255f, c.getGreen() / 255f, c.getBlue() / 255f, c.getAlpha() / 255f);

        Layers.getGlobalLines(lineWidth).method_60895(bufferBuilder.method_60800());
    }

    public static void drawBox(class_4587 stack, class_243 vec, Color c, double lineWidth) {
        drawBox(stack, class_238.method_29968(vec), c, lineWidth);
    }

    public static void drawBox(class_4587 stack, class_2338 bp, Color c, double lineWidth) {
        drawBox(stack, new class_238(bp), c, lineWidth);
    }

    public static class_4587 matrixFrom(class_243 pos) {
        class_4587 matrices = new class_4587();
        class_4184 camera = mc.field_1773.method_19418();
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
        matrices.method_22904(pos.method_10216() - camera.method_19326().field_1352, pos.method_10214() - camera.method_19326().field_1351, pos.method_10215() - camera.method_19326().field_1350);
        return matrices;
    }
}
