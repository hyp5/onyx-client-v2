package me.alpha432.oyvey.util.font;

import java.awt.*;
import java.io.InputStream;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class TTFFontRenderer {

    private final class_310 mc = class_310.method_1551();
    private final Font font;

    public TTFFontRenderer(InputStream stream, float size) throws Exception {
        Font base = Font.createFont(Font.TRUETYPE_FONT, stream);
        this.font = base.deriveFont(size);
    }

    public void drawString(class_332 context, String text, int x, int y, int color) {
        if (text == null) return;
        context.method_25303(mc.field_1772, text, x, y, color);
    }

    public int getWidth(String text) {
        return mc.field_1772.method_1727(text);
    }

    public int getHeight() {
        return mc.field_1772.field_2000;
    }
}
