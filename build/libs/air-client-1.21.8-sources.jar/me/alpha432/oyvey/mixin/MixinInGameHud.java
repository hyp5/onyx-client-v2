package me.alpha432.oyvey.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import me.alpha432.oyvey.event.impl.Render2DEvent;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static me.alpha432.oyvey.util.traits.Util.EVENT_BUS;

@Mixin(class_329.class)
public class MixinInGameHud {

    @Inject(method = "render", at = @At("RETURN"))
    public void render(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (class_310.method_1551().field_1705.method_53531().method_53536()) return;

        Render2DEvent event = new Render2DEvent(context, tickCounter.method_60637(true));
        EVENT_BUS.post(event);
    }

}
