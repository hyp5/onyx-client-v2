package me.alpha432.oyvey.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import me.alpha432.oyvey.event.impl.Render3DEvent;
import net.minecraft.class_3695;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static me.alpha432.oyvey.util.traits.Util.EVENT_BUS;
import static me.alpha432.oyvey.util.traits.Util.mc;

@Mixin(class_761.class)
public class MixinWorldRenderer {
    @Inject(method = "render", at = @At("RETURN"))
    private void render(class_9922 allocator, class_9779 tickCounter, boolean renderBlockOutline,
                        class_4184 camera, Matrix4f positionMatrix, Matrix4f projectionMatrix, GpuBufferSlice gpuBufferSlice, Vector4f viewArea, boolean someFlag,
                        CallbackInfo ci, @Local class_3695 profiler) {
        class_4587 stack = new class_4587();
        stack.method_22903();
        stack.method_22907(class_7833.field_40714.rotationDegrees(mc.field_1773.method_19418().method_19329()));
        stack.method_22907(class_7833.field_40716.rotationDegrees(mc.field_1773.method_19418().method_19330() + 180f));

        profiler.method_15396("oyvey-render-3d");

        Render3DEvent event = new Render3DEvent(stack, tickCounter.method_60637(true));
        EVENT_BUS.post(event);
        stack.method_22909();
        profiler.method_15407();
    }
}