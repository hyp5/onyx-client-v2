package me.alpha432.oyvey.manager;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.event.impl.UpdateEvent;
import me.alpha432.oyvey.features.Feature;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class HoleManager extends Feature {
    private final int range = 8;
    private final List<Hole> holes = new ArrayList<>();
    private final class_2338.class_2339 pos = new class_2338.class_2339();

    public HoleManager() {
        EVENT_BUS.register(this);
    }

    @Subscribe
    private void onTick(UpdateEvent event) {
        holes.clear();
        for (int x = -range; x < range; x++) {
            for (int y = -range; y < range; y++) {
                for (int z = -range; z < range; z++) {
                    pos.method_10102(mc.field_1724.method_23317() + x, mc.field_1724.method_23318() + y, mc.field_1724.method_23321() + z);
                    Hole hole = getHole(pos);
                    if (hole == null) continue;
                    holes.add(hole);
                }
            }
        }
    }

    @Nullable
    public Hole getHole(class_2338 pos) {
        if (mc.field_1687.method_8320(pos).method_26204() != class_2246.field_10124)
            return null;
        HoleType type = HoleType.BEDROCK;
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2248 block = mc.field_1687.method_8320(pos.method_10093(direction)).method_26204();
            if (block == class_2246.field_10540) type = HoleType.UNSAFE;
            else if (block != class_2246.field_9987) return null;
        }
        return new Hole(pos, type);
    }

    public List<Hole> getHoles() {
        return holes;
    }

    public boolean isHole(class_2338 pos) {
        return holes.stream().anyMatch(hole -> hole.pos().equals(pos));
    }

    public record Hole(class_2338 pos, HoleType holeType) {
    }

    private enum HoleType {
        BEDROCK,
        UNSAFE;
    }
}
