package me.alpha432.oyvey.manager;

import com.google.common.eventbus.Subscribe;
import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.event.Stage;
import me.alpha432.oyvey.event.impl.*;
import me.alpha432.oyvey.features.Feature;
import me.alpha432.oyvey.features.commands.Command;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2658;
import net.minecraft.class_2761;
import net.minecraft.class_8709;

public class EventManager extends Feature {
    public void init() {
        EVENT_BUS.register(this);
    }

    public void onUnload() {
        EVENT_BUS.unregister(this);
    }

    @Subscribe
    public void onUpdate(UpdateEvent event) {
        if (!nullCheck()) {
            OyVey.moduleManager.onUpdate();
            onTick();
        }
    }

    public void onTick() {
        if (nullCheck())
            return;
        OyVey.moduleManager.onTick();
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == null || player.method_6032() > 0.0F)
                continue;
            EVENT_BUS.post(new DeathEvent(player));
        }
    }

    @Subscribe
    public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
        if (nullCheck())
            return;
        if (event.getStage() == Stage.PRE) {
            OyVey.speedManager.update();
            OyVey.rotationManager.updateRotations();
            OyVey.positionManager.updatePosition();
        }
        if (event.getStage() == Stage.POST) {
            OyVey.rotationManager.restoreRotations();
            OyVey.positionManager.restorePosition();
        }
    }

    @Subscribe
    public void onPacketReceive(PacketEvent.Receive event) {
        OyVey.serverManager.onPacketReceived();
        if (event.getPacket() instanceof class_2761)
            OyVey.serverManager.update();
        if (event.getPacket() instanceof class_2658(CustomPayload payload)
                && payload instanceof class_8709(String brand)) {
            OyVey.serverManager.setServerBrand(brand);
        }
    }

    @Subscribe
    public void onWorldRender(Render3DEvent event) {
        OyVey.moduleManager.onRender3D(event);
    }

    @Subscribe
    public void onRenderGameOverlayEvent(Render2DEvent event) {
        OyVey.moduleManager.onRender2D(event);
    }

    @Subscribe
    public void onKeyInput(KeyEvent event) {
        OyVey.moduleManager.onKeyPressed(event.getKey());
    }

    @Subscribe
    public void onChatSent(ChatEvent event) {
        if (event.getMessage().startsWith(Command.getCommandPrefix())) {
            event.cancel();
            try {
                if (event.getMessage().length() > 1) {
                    OyVey.commandManager.executeCommand(event.getMessage().substring(Command.getCommandPrefix().length() - 1));
                } else {
                    Command.sendMessage("Please enter a command.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                Command.sendMessage(class_124.field_1061 + "An error occurred while running this command. Check the log!");
            }
        }
    }
}