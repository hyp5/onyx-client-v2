package me.alpha432.oyvey.event.impl;

import me.alpha432.oyvey.event.Event;
import net.minecraft.class_4587;

public class Render3DEvent extends Event {
    private final class_4587 matrix;
    private final float delta;

    public Render3DEvent(class_4587 matrix, float delta) {
        this.matrix = matrix;
        this.delta = delta;
    }

    public class_4587 getMatrix() {
        return matrix;
    }

    public float getDelta() {
        return delta;
    }
}
