package me.alpha432.oyvey.event.impl;

import me.alpha432.oyvey.event.Event;
import net.minecraft.class_1309;

public class DeathEvent extends Event {
    private final class_1309 entity;

    public DeathEvent(class_1309 entity) {
        this.entity = entity;
    }

    public class_1309 getEntity() {
        return entity;
    }
}
