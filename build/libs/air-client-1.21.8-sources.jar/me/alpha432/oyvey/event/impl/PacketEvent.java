package me.alpha432.oyvey.event.impl;

import me.alpha432.oyvey.event.Event;
import net.minecraft.class_2596;

public abstract class PacketEvent extends Event {

    private final class_2596<?> packet;

    public PacketEvent(class_2596<?> packet) {
        this.packet = packet;
    }

    public class_2596<?> getPacket() {
        return packet;
    }

    public static class Receive extends PacketEvent {
        public Receive(class_2596<?> packet) {
            super(packet);
        }
    }

    public static class Send extends PacketEvent {
        public Send(class_2596<?> packet) {
            super(packet);
        }
    }

}